package com.productos;


public class Pantalones extends Productos{
	private String [] nombre = new String [3];
	
	
	public String[] getNombre() {
		return nombre;
	}
	public void setNombre(String[] nombre) {
		this.nombre = nombre;
	}
	
	public String tipo(String comparar) {
			String producto = null;
		switch (comparar) {
		case "Pantalon1":
				producto = nombre[0];
			break;
		case "Pantalon2":
			producto = nombre[1];
			break;
		case "Pantalon3":
			producto = nombre[2];
			break;
		default:
			producto = "No hay pantal�n seleccionado.";
			break;
		}
		
		return producto;

	}
		
	
}
