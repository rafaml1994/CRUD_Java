package com.productos;


public class Camisas extends Productos{
	private String [] nombre = new String [3];

	
	
	public String[] getNombre() {
		return nombre;
	}
	public void setNombre(String[] nombre) {
		this.nombre = nombre;
	}
	
	//--->> OVERRIDE(SOBRESCRITURA): SE DA PRINCIPALMENTE EN LOS M�TODOS DE LAS CLASES HIJAS, HEREDADAS DE UNA CLASE PADRE.
	//--->> OVERLOADING(SOBRECARGA): SE PRODUCE CUANDO A UN M�TODO TIENE LA MISMA FIRMA PERO DISTINTO N�MERO DE ARGUMENTOS.
	
	
	public String tipo(String comparar) {
			String producto = null;
		switch (comparar) {
		case "Camisa1":
			producto = nombre[0];
			break;
		case "Camisa2":
			producto = nombre[1];
			break;
		case "Camisa3":
			producto = nombre[2];
			break;
		default:
			producto = "No hay camisa seleccionada";
			break;
		}
		
		return producto;

	}
		
	
}
