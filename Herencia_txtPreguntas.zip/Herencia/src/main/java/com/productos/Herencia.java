package com.productos;

public class Herencia {

	public static void main(String[] args) {
		
		//CREAMOS EL OBJETO CAMISA:
		
		Camisas camisa = new Camisas();
		
		//CREAMOS UN ARRAY PARA LOS NOMBRES DE LAS CAMISAS QUE LE VAMOS A PASAR COMO PAR�METROS AL OBJETO CAMISA:
		
		String nombreC[] = new String[3];
		
		nombreC[0] = "Camisa Polo";
		nombreC[1] = "Camisa Tommy";
		nombreC[2] = "Camisa Levis";

		
		camisa.setNombre(nombreC);
		
		Pantalones pantalon = new Pantalones();
		
		String nombreP[] = new String[3];
		
		nombreP[0] = "Pantalon Levis";
		nombreP[1] = "Pantalon Polo";
		nombreP[2] = "Pantalon Chandal";

		
		pantalon.setNombre(nombreP);
		
		//CREAMOS EL OBJETO PRODUCTOS:
		
		Productos producto = new Productos();
		
		//ESTABLECEMOS LA ID CON LA QUE VAMOS A TRABAJAR. EN CASO DE NO SELECCIONAR ID, HAY UN VALOR PREDETERMINADO.
		
		producto.setIdProducto(2);

		//COMO VEMOS EL M�TODO PADRE SOLO NOS DEVUELVE EL TIPO DE PRODUCTO EN FUNCION DE LA ID
		System.out.println("El tipo de producto es: "+producto.tipo());
		
		// EN CAMBIO AL LLAMAR AL M�TODO "TIPO" DE LAS CLASES HIJAS USANDO EL RESULTADO DEL METODO PADRE, VEMOS QUE COMO RESULTADO NOS DA EL PANTAL�N O LA CAMISA QUE HAYAMOS PUESTO EN FUNCION DE LA ID.
		
		System.out.println("La camisa seg�n la ID es: "+camisa.tipo(producto.tipo()));
		System.out.println("El pantal�n seg�n la ID es: "+pantalon.tipo(producto.tipo()));
		
		//Java no admite la herencia m�ltiple, es decir, no podemos  heredar las propiedades o m�todos desde dos clases "padre" a una �nica clase "hija". Esto es as� debido a que los creadores de Java prohibieron 
		//la herencia multiple para evitar la ambiguedad del c�digo y que sea lo m�s limpio y legible posible. Adem�s creen que la herencia multiple daba m�s problemas de los que resolv�a.
		
		
	}

}
