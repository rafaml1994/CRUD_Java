package com.productos;

public class Productos {
	private int idProducto;
	public int getIdProducto() {
		return idProducto;
	}
	public void setIdProducto(int idProducto) {
		this.idProducto = idProducto;
	}

	
	public String tipo() {
		String tipoProducto = null;
		switch (idProducto) {
		case 1:
			tipoProducto = "Camisa1";
			break;
		case 2:
			tipoProducto = "Camisa2";
			break;
		case 3:
			tipoProducto = "Camisa3";
			break;
		case 4:
			tipoProducto = "Pantalon2";
			break;
		case 5:
			tipoProducto = "Pantalon3";
			break;
		default:
			tipoProducto = "Pantalon1";
			break;
		}
		return tipoProducto;	
	}
}
