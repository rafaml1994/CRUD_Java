import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class GenerarPDF {

	public static void main(String[] args) {
		System.out.println("Bienvenido a nuestro concurso, responda a las preguntas que van a aperecer a continuaci�n");
		try {
			BufferedReader br = new BufferedReader(new FileReader("src/main/java/Preguntas.txt"));
			BufferedReader respuestas = new BufferedReader(new FileReader("src/main/java/Respuestas.txt"));
			float contador = 0;
			int contadorRespuesta = 1;
			try {
				String linea;
				
				//Si no lo metemos en una variable tipo String , las lineas saltan de dos en dos y da problemas y fallos.
				
				while((linea = br.readLine()) != null) {
					System.out.println(linea);
					Scanner sc = new Scanner(System.in);
					String respuesta = sc.nextLine();
					String cadena = respuestas.readLine().toUpperCase();

					//Lo mismo pasa aqu�, si no lo metemos como tipo String salta de dos en dos y da fallo.
					
					String cadenaRespuesta = ("Pregunta "+contadorRespuesta+" : "+respuesta).toUpperCase();
					contadorRespuesta++;
					if(cadenaRespuesta.equals(cadena)) {
						contador++;
						System.out.println("Respuesta correcta! + 1 punto.");
					}else {
						System.out.println("Has fallado! -0,5 puntos." );
						contador-=0.5f;
					}
					//sc.close();
				}
			System.out.println(("El resultado obtenido es : "+contador).toUpperCase());
			if(contador<=0) 
				System.out.println("No me creo que hayas sacado "+contador+" ponte a estudiar YA");
			else if(contador>=5 && contador <= 9) 
				System.out.println("Has aprobado, bien hecho");
			else if(contador == 10)
				System.out.println("Eres la excelencia en persona!!");			

			br.close();
			respuestas.close();
			} catch (IOException e) {

				System.out.println(e);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
	}
	
	

}
